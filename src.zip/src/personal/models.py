from django.db import models



class Report(models.Model):
	client					= models.CharField(max_length=100)
	requirement				= models.TextField(max_length=500)
	time_spent_on_sourcing  = models.IntegerField()
	mode_used				= models.TextField()
	no_of_cvs_sourced		= models.IntegerField()
	time_spent_on_calls		= models.IntegerField()
	no_of_calls_made		= models.IntegerField()
	cvs_submitted_office_id	= models.TextField()
	cvs_submitted_client	= models.TextField()
	challengs_remarks		= models.TextField()


class Client(models.Model):
	"""docstring for Client"""
	clientname 				= models.CharField(max_length=200)
	
		