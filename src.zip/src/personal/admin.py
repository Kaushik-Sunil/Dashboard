from django.contrib import admin
from personal.models import Report
from personal.models import Client


admin.site.register(Report)
admin.site.register(Client)



